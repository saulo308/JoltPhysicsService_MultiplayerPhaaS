Race tracks taken from: https://github.com/TUMFTM/racetrack-database

See LICENSE.txt for license for these race tracks.